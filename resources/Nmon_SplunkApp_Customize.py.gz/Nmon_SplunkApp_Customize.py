#!/usr/bin/env python

# Program name: customize_IndexName.py
# Compatibility: Python 2x
# Purpose - Customize the index name for the Splunk Nmon App, see https://apps.splunk.com/app/1753
# Author - Guilhem Marchand
# Disclaimer: Distributed on an "AS IS" basis
# Date of first publication - August 2014

# Licence:

# Copyright 2014 Guilhem Marchand

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Releases Notes:

# - August 2014, V1.0.0: Guilhem Marchand, Initial version
# - 09/07/2014, V1.0.1: Guilhem Marchand, Python PEP 8 compliance
# - 09/09/2014, V1.0.2: Guilhem Marchand:
#                       . Improved parser arguments verification
#                       . check existing directory before processing
#                       . backward compatibility with Python 2.6
# - 09/09/2014, V1.0.3: Guilhem Marchand:
#                       . Portable shebang correction
#                       . Corrected missing string replacement for calendar heatmap views
# - 10/08/2014, V1.0.4: Guilhem Marchand:
#                       . Corrected missing string replacement for UARG links in Framework views
# - 27/08/2014, V1.0.5: Guilhem Marchand:
#			. Missing string replacement for dispatch ui in savedsearches.conf
# - 15/11/2014, V1.0.6: Guilhem Marchand:
#                       . Deleted useless removal of pyo files (forbidden files in release, shall never be present)
# - 13/02/2015, V1.0.7: Guilhem Marchand:
#                       - Cleaning improvements
# - 12/03/2015, V1.0.8: Guilhem Marchand: savedsearches.conf update requires idx to be modifier
# - 01/04/2015, V1.0.9: Guilhem Marchand: Update for Dendogram Vizualization
# - 20/05/2015, V1.0.10: Guilhem Marchand: compliant update with Nmon Splunk App starting V1.5.25 (removing of TA-nmon
#                                           PA-nmon directories (only tar versions are kept for app size optimization)
# - 28/07/2015, V1.0.11: Guilhem Marchand: Hotfix for V1.6.0 of the Application (broken link in Home for triggered UI)
# - 12/09/2015, V1.0.12: Guilhem Marchand: Broken replacement for Home Page easy access links
# - 23/12/2015, V1.0.13: Guilhem Marchand: Non supported replacement for pivot href in app bar introduced
#  in release 1.6.12 (git issue #14)

import sys
import os
import tarfile
import glob
import fnmatch
import argparse

version = '1.0.13'

# ###################################################################
#############           Arguments Parser
####################################################################

# Define Arguments

parser = argparse.ArgumentParser()

parser.add_argument('-f', action='store', dest='INFILE',
                    help='Name of the Nmon Splunk APP tgz Archive file')

parser.add_argument('-i', action='store', dest='INDEX_NAME',
                    help='Customize the Application Index Name (default: nmon)')

parser.add_argument('-r', action='store', dest='ROOT_DIR',
                    help='Customize the Application Root Directory (default: nmon)')

parser.add_argument('-a', action='store', dest='TA_NMON',
                    help='Customize the TA NMON Root Directory (default: TA-nmon)')

parser.add_argument('-p', action='store', dest='PA_NMON',
                    help='Customize the PA NMON Root Directory (default: PA-nmon)')

parser.add_argument('--csvrepo', action='store', dest='CSV_REPOSITORY',
                    help='Customize the local CSV Repository (default: csv_repository)')

parser.add_argument('--configrepo', action='store', dest='CONFIG_REPOSITORY',
                    help='Customize the local Config Repository (default: config_repository)')

parser.add_argument('--version', action='version', version='%(prog)s ' + version)

args = parser.parse_args()

####################################################################
#############           Functions
####################################################################

# String replacement function
# Can be called by:
# findreplace(path, string_to_search, replace_by, file_extension)

def findreplace(directory, find, replace, filepattern):
    for path, dirs, files in os.walk(os.path.abspath(directory)):
        for filename in fnmatch.filter(files, filepattern):
            filepath = os.path.join(path, filename)
            with open(filepath) as f:
                s = f.read()
            s = s.replace(find, replace)
            with open(filepath, "w") as f:
                f.write(s)

####################################################################
#############           Main Program
####################################################################

# Check Arguments
if len(sys.argv) < 2:
    print "\n%s" % os.path.basename(sys.argv[0])
    print "\nIf for some reason you need to customize the Nmon Splunk Application, please follow these instructions:\n"
    print "- Download the current release of Nmon App in Splunk Base: https://apps.splunk.com/app/1753"
    print "- Uncompress the Nmon_SplunkApp_Customize.py.gz"
    print "- Place the downloaded tgz Archive and this Python tool in the directory of your choice"
    print "- Run the tool: ./customize_indexname.py and check for available options\n"
    print "After the execution, the Application (including TA-nmon and PA-nmon in resources) will have been customized and are ready to be used\n"
    sys.exit(0)

# Will expect in first Argument the name of the tgz Archive of the Application to be downloaded in Splunk Base
if not (args.INFILE):
    print "\nERROR: Please provide the tgz Archive file with -f statement\n"
    sys.exit(1)
else:
    infile = args.INFILE

# Will expect the customize name of the Splunk index, the default name of the index is "nmon"
if not (args.INDEX_NAME):
    print "INFO: No custom index name were provided, using default \"nmon\" name for index"
    index_name = "nmon"
else:
    index_name = args.INDEX_NAME

# If the root directory is not defined, apply default "nmon" value
if not (args.ROOT_DIR):
    print "INFO: No custom root directory of the nmon App core App were provided, using default \"nmon\" name for root directory"
    root_dir = "nmon"
else:
    root_dir = args.ROOT_DIR

# If the root directory of the TA-nmon is not defined, apply default 'TA-nmon' value
if not (args.TA_NMON):
    print "INFO: No custom root directory of the TA-nmon were provided, using default \"TA-nmon\" name for TA-nmon root directory"
    ta_root_dir = "TA-nmon"
else:
    ta_root_dir = args.TA_NMON

# If the root directory of the PA-nmon is not defined, apply default 'PA-nmon' value
if not (args.PA_NMON):
    print "INFO: No custom root directory of the PA-nmon were provided, using default \"PA-nmon\" name for PA-nmon root directory"
    pa_root_dir = "PA-nmon"
else:
    pa_root_dir = args.PA_NMON

# If the csv_repository is not defined, apply default 'csv_repository' value
if not (args.CSV_REPOSITORY):
    print "INFO: No custom csv reposity directory were provided, using default \"csv_repository\" name for csv repository root directory"
    csv_repository = "csv_repository"
else:
    csv_repository = args.CSV_REPOSITORY

# If the config_repository is not defined, apply default 'config_repository' value
if not (args.CONFIG_REPOSITORY):
    print "INFO: No custom csv reposity directory were provided, using default \"config_repository\" name for csv repository root directory"
    config_repository = "config_repository"
else:
    config_repository = args.CONFIG_REPOSITORY

# Verify tgz Archive file exists
if not os.path.exists(infile):
    print ('ERROR: invalid file, could not find: ' + infile)
    sys.exit(1)

# If root_dir already exist in current directory
if os.path.exists(root_dir):
    print ('ERROR: A directory named ' + root_dir + ' already exist in current directory, please remove it and restart')
    sys.exit(1)

# Extract Archive
tar = tarfile.open(infile)
msg = 'Extracting tgz Archive: ' + infile
print (msg)
tar.extractall()
tar.close()

# Extracting TA-nmon and PA-nmon

# Get current directory
curdir = os.getcwd()

# cd to nmon/resources
path = 'nmon/resources'
os.chdir(path)

tgz_files = '*A-nmon_*.tar.gz'

for tgz in glob.glob(str(tgz_files)):
    tar = tarfile.open(tgz)
    msg = 'Extracting tgz Archive: ' + tgz
    print (msg)
    tar.extractall()
    tar.close()

os.chdir(curdir)

# Operate

# If the root_dir does not equal to default root dir of Nmon Splunk App (nmon), let's customize

if root_dir != "nmon":
    msg = 'INFO: Changing the App Root Directory from default "nmon" to custom "' + root_dir + '"'
    print(msg)

    # Dir rename
    os.rename("nmon", root_dir)

    # Get current directory
    curdir = os.getcwd()

    # cd to django
    path = root_dir + '/django'
    os.chdir(path)

    # Dir rename
    os.rename("nmon", root_dir)

    # cd to django static
    path = root_dir + '/static'
    os.chdir(path)

    # Dir rename
    os.rename("nmon", root_dir)

    os.chdir(curdir)

    path = root_dir + '/django/' + root_dir + '/templatetags/'
    os.chdir(path)

    rename = root_dir + '.py'
    os.rename("nmon.py", rename)
    
    # Return to origin
    os.chdir(curdir)

    ################# STRING REPLACEMENTS #################

    # Replace string in files

    path = root_dir
    extension = "*"

    # Achieve string replacements

    print ('Achieving files transformation:')

    # Replace basic index calls
    print ('INFO: Customizing any reference to default root directory in files')

    search = 'static/app/nmon'
    replace = 'static/app/' + root_dir
    findreplace(path, search, replace, extension)

    search = 'app/nmon/components'
    replace = 'app/' + root_dir + '/components'
    findreplace(path, search, replace, extension)

    search = 'app/nmon'
    replace = 'app/' + root_dir
    findreplace(path, search, replace, extension)

    search = 'etc/apps/nmon'
    replace = 'etc/apps/' + root_dir
    findreplace(path, search, replace, extension)

    search = 'etc\\\\apps\\\\nmon'
    replace = 'etc\\\\apps\\\\' + root_dir
    findreplace(path, search, replace, extension)

    # Web Framework views

    # Specify extension to avoid collision with previous component replacement
    search = 'nmon/components'
    replace = root_dir + '/components'
    findreplace(path, search, replace, '*.py')

    # Specify extension to avoid collision with previous component replacement
    search = 'nmon/components'
    replace = root_dir + '/components'
    findreplace(path, search, replace, '*.html')

    search = 'nmon/contrib'
    replace = root_dir + '/contrib'
    findreplace(path, search, replace, extension)

    search = '{{STATIC_URL}}/nmon'
    replace = '{{STATIC_URL}}/' + root_dir
    findreplace(path, search, replace, extension)

    search = '{{STATIC_URL}}nmon'
    replace = '{{STATIC_URL}}' + root_dir
    findreplace(path, search, replace, extension)

    search = 'dj/en-us/nmon'
    replace = 'dj/en-us/' + root_dir
    findreplace(path, search, replace, extension)

    search = 'load nmon'
    replace = 'load ' + root_dir
    findreplace(path, search, replace, extension)

    search = 'uri=*/app/nmon/*'
    replace = 'uri=*/app/' + root_dir + '/*'
    findreplace(path, search, replace, extension)

    search = 'uri=*/dj/*/nmon/*'
    replace = 'uri=*/dj/*/' + root_dir + '/*'
    findreplace(path, search, replace, extension)

    search = 'app="nmon"'
    replace = 'app="' + root_dir + '"'
    findreplace(path, search, replace, extension)

    # Replace dispatch ui in savedsearches.conf
    search = 'request.ui_dispatch_app = nmon'
    replace = 'request.ui_dispatch_app = ' + root_dir
    findreplace(path, search, replace, "savedsearches.conf")

    # Home page triggered alerts interface link
    search = '/alerts/nmon'
    replace = '/alerts/' + root_dir
    findreplace(path, search, replace, "Home*.xml")

    # App bar customization dedicated
    search = '%2Fnmon%2Fdatamodel'
    replace = '%2F' + root_dir + '%2Fdatamodel'
    findreplace(path, search, replace, "default.xml")

    search = '/manager/nmon/'
    replace = '/manager/' + root_dir + '/'
    findreplace(path, search, replace, "default.xml")

    search = 'ns=nmon'
    replace = 'ns=' + root_dir
    findreplace(path, search, replace, "default.xml")

# If the root_dir has been found (else specified the default value, else used an archive file containing the good root_dir)

if os.path.exists(root_dir):

    # Change index name only if differs from default index name (nmon)
    if index_name != "nmon":
        ################# STRING REPLACEMENTS #################

        # Replace string in files

        path = root_dir
        extension = "*"

        # Achieve string replacements

        print ('Achieving files transformation:')

        # Replace basic index calls
        print ('INFO: Customizing any reference to index name in files')

        replace = 'index=' + index_name
        findreplace(path, "index=nmon", replace, extension)

        replace = 'index="' + index_name + '"'
        findreplace(path, "index=\"nmon\"", replace, extension)

        search = 'idx=nmon'
        replace = 'idx=' + index_name
        findreplace(path, search, replace, "*")

        search = 'index = nmon'
        replace = 'index = ' + index_name
        findreplace(path, search, replace, "*")

        search = 'series=nmon'
        replace = 'series=' + index_name
        findreplace(path, search, replace, "*")

        search = 'series="nmon"'
        replace = 'series="' + index_name + '"'
        findreplace(path, search, replace, "*")
		
        # Home page data links
        search = 'target="_blank">nmon</a>'
        replace = 'target="_blank">' + index_name + '</a>'
        findreplace(path, search, replace, "Home*.xml")

        # Howto pages data code replacements
        search = 'index%3Dnmon'
        replace = 'index%3D' + index_name
        findreplace(path, search, replace, "*.xml")		

        # Replace index configuration in indexes.conf
        print ('INFO: Customizing indexes.conf')
        findreplace(path, "nmon", index_name, "indexes.conf")

        #######################################################

    # CSV and CONFIG repository

    if csv_repository != "csv_repository":
        ################# STRING REPLACEMENTS #################

        # Replace string in files

        path = root_dir
        extension = "*"

        # Achieve string replacements

        # Replace basic index calls
        msg = 'INFO: Customizing csv_repository to ' + csv_repository
        print (msg)

        search = 'csv_repository'
        replace = csv_repository
        findreplace(path, search, replace, extension)

        #######################################################

    if config_repository != "config_repository":
        ################# STRING REPLACEMENTS #################

        # Replace string in files

        path = root_dir
        extension = "*"

        # Achieve string replacements

        # Replace basic index calls
        msg = 'INFO: Customizing config_repository to ' + config_repository
        print (msg)

        search = 'config_repository'
        replace = config_repository
        findreplace(path, search, replace, extension)

        #######################################################

    # Get current directory
    curdir = os.getcwd()

    # cd to resources
    path = root_dir + '/resources'
    os.chdir(path)

    # Customize TA-nmon only if default differs from the one provided in argument
    if ta_root_dir != "TA-nmon":

        path = root_dir + '/resources'

        print ('INFO: Removing tgz resources Archives')

        tgz_files = 'TA-nmon*.tar.gz'

        for tgz in glob.glob(str(tgz_files)):
            os.remove(tgz)

        msg = 'INFO: Customizing the TA-nmon Root directory from the default TA-nmon to ' + ta_root_dir
        print (msg)

        os.rename('TA-nmon', ta_root_dir)
        findreplace(".", 'TA-nmon', ta_root_dir, "*")

        # Don't use "with" statement in tar creation for Python 2.6 backward compatibility
        tar_file = ta_root_dir + '_custom.tar.gz'
        out = tarfile.open(tar_file, mode='w:gz')

        try:
            out.add(ta_root_dir)
        finally:
            msg = 'INFO: ************* Tar creation done of: ' + tar_file + ' *************'
            print (msg)
            out.close()

    # Customize PA-nmon only if default differs from the one provided in argument
    if pa_root_dir != "PA-nmon":

        path = root_dir + '/resources'

        print ('INFO: Removing tgz resources Archives')

        tgz_files = 'PA-nmon*.tar.gz'

        for tgz in glob.glob(str(tgz_files)):
            os.remove(tgz)

        msg = 'INFO: Customizing the PA-nmon Root directory from the default PA-nmon to ' + pa_root_dir
        print (msg)

        os.rename('PA-nmon', pa_root_dir)
        findreplace(".", 'PA-nmon', pa_root_dir, "*")

        # Don't use "with" statement in tar creation for Python 2.6 backward compatibility
        tar_file = pa_root_dir + '_custom.tar.gz'
        out = tarfile.open(tar_file, mode='w:gz')

        try:
            out.add(pa_root_dir)
        finally:
            msg = 'INFO: ************* Tar creation done of: ' + tar_file + ' *************'
            print (msg)
            out.close()
            # Clean standard PA-nmon


    # Return to origin dir
    os.chdir(curdir)

    print ('INFO: Creating the custom nmon_performance_monitor_custom.spl archive in current root directory')
    tar_file = "nmon_performance_monitor_custom.spl"
    with tarfile.open(tar_file, "w:gz") as tar:
        for name in [root_dir]:
            tar.add(name)
            msg = 'INFO: ************* Tar creation done of: ' + tar_file + ' *************'
            print (msg)

    print ('\n*** To install your customized packages: ***\n')
    print (' - Extract the content of nmon_performance_monitor_custom.spl to Splunk Apps directory of your search heads (or use the manager to install the App)')
    print (' - Extract the content of the PA package available in resources directory to your indexers')
    print (' - Extract the content of the TA package available in resources directory to your deployment server or clients \n')

    # END
    print ('Operation terminated.\n')
    sys.exit(0)

else:

    msg = 'ERROR: The Application Root Directory ' + root_dir + ' could not be found the tgz Archive file, please verify your settings.'
    print (msg)
    sys.exit(1)
